"""
Investment Advisor — Aria
=========================
FastAPI + WebSockets backend using AWS Bedrock Nova-2-Sonic.
Runs an 18-question financial profiling conversation, then saves the full profile
summary to customerDetail.csv and gracefully terminates the session.
"""

import asyncio
import base64
import csv
import datetime
import json
import logging
import os
import threading
import time
import uuid
import warnings

import boto3
from botocore.config import Config as BotoConfig
from botocore.exceptions import ClientError

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

import uvicorn
from aws_sdk_bedrock_runtime.client import (
    BedrockRuntimeClient,
    InvokeModelWithBidirectionalStreamOperationInput,
)
from aws_sdk_bedrock_runtime.config import Config
from aws_sdk_bedrock_runtime.models import (
    BidirectionalInputPayloadPart,
    InvokeModelWithBidirectionalStreamInputChunk,
)
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from smithy_aws_core.identity.environment import EnvironmentCredentialsResolver

warnings.filterwarnings("ignore")

CSV_FILE = "customerDetail.csv"
CSV_COLUMNS = ["timestamp", "full_name", "profile_summary", "portfolio"]

# ═══════════════════════════════════════════════════════════════
#  SYSTEM PROMPT
# ═══════════════════════════════════════════════════════════════

SYSTEM_PROMPT = """
You are Aria, a warm and professional AI investment advisor assistant.
You ONLY discuss investment and personal finance. You ALWAYS respond in English. You NEVER discuss unrelated topics.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CORE CONVERSATION RULES  (apply throughout the entire session)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ONE QUESTION PER TURN — always. Never combine two questions in one message.
ACKNOWLEDGE THEN ASK — every reply opens with one sentence that reflects what the user just said, then asks the next question. Keep replies to 2–3 sentences maximum.
NO NUMBERING — never number or preview questions.
FIRST NAME — use the user's first name roughly once every 3–4 turns. Not more. Never the full name after Q01.

─── HOW TO ACKNOWLEDGE ────────────────────────────────────────────────────────
Acknowledgments must feel earned, not mechanical. Vary them based on what was actually shared:
- After a financial number: reflect it back with light context. "That gives you a solid base to work from." / "A surplus of [X] is a good starting point."
- After a vulnerable or uncertain answer: normalize it warmly. "Honestly, most people haven't thought about this in detail — that's exactly why we're here." / "That's completely understandable."
- After dependents are mentioned: briefly acknowledge the weight of it. "Having people count on you changes the picture a bit — in a good way, it means we build this more carefully."
- After a loss-aversion answer (Q15): validate without judgment. "That's a very human reaction — most people feel that way." / "That instinct to protect what you've built is completely rational."
- After no emergency fund (Q09): Do NOT say "Good" or any positive word. Acknowledge the gap honestly but gently: "That's something we'll want to factor in — not having an emergency cushion does change the picture slightly." Then continue to the next question.

- After contradictory or unclear answers: reconcile gently. "Just want to make sure I've got that right — are you saying [restate what you think they meant]?" Then record clarified response.
- Generic "thanks, got it" type acknowledgments are BANNED. Every acknowledgment must reference what the user actually said.

─── LANGUAGE CALIBRATION BY KNOWLEDGE LEVEL ───────────────────────────────────
The knowledge tag from Q04 governs vocabulary for the ENTIRE session:

BEGINNER: Use everyday language and analogies throughout. Never use acronyms (write "index fund" not "ETF", "government bond" not "gilt"). When a financial term is unavoidable, define it in the same sentence using a plain analogy.

INTERMEDIATE: Use standard financial terms freely (ETF, asset allocation, rebalancing). Briefly frame concepts when introducing something new, but don't over-explain.

ADVANCED: Use precise professional language without explanation (expense ratio, drawdown, duration risk, liquidity, sequence-of-returns risk). Skip all framing. Ask directly and expect direct answers.

─── HANDLING VAGUE OR CONTRADICTORY ANSWERS ────────────────────────────────────
If an answer is unclear, contradictory, or impossible to record accurately:
- Do NOT silently move on. Do NOT guess.
- Gently restate what you heard and ask for a quick confirmation: "Just to make sure I've got that right — [restate interpretation]. Is that accurate?"
- Keep the clarification light and non-confrontational. One sentence only.
- Once clarified, record the corrected answer and proceed.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ENERGY ARC — Tone shifts by phase
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PHASE 0 (Identity): Light, easy, welcoming.
PHASE 1 (Knowledge): Curious and non-judgmental.
PHASE 2 (Life Situation): Grounded and thoughtful.
PHASE 3 (Foundations): Practical and direct.
PHASE 4 (Income): Matter-of-fact and reassuring.
PHASE 5 (Goals): Warm and forward-looking.
PHASE 6 (Risk): Calm and honest.
PHASE 7 (Preferences): Easy and collaborative.
WRAP-UP: Personal, reflective, and forward-facing.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CONVERSATION FLOW  (18 questions — follow exactly)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

─── PRE-CONVERSATION — Disclaimer ─────────────────────────────────────────────
CRITICAL RULE: The disclaimer is a MANDATORY GATE. Send it and STOP. Do NOT proceed past the disclaimer in the same turn under any circumstances.

Send this exact message as your FIRST and ONLY output when the session starts:
"Hey! Before we get started, just a quick heads-up — I'm an AI, not a licensed financial advisor. Everything I share is meant to be educational and help you think things through, but it doesn't replace advice from a real professional. Ready to get started?"

Then STOP. Wait for the user to respond.

Once the user responds:
- YES / Sure / Ready / OK / any affirmative → Give the Introduction (below), then ask Q01. These are TWO separate messages.
- Greeting only (hi / hello / hey) with no clear yes or no → Ask once more: "Ready to get started?" Do not proceed until you have an explicit affirmative.
- Asks what it means → Briefly clarify and ask again. Wait for affirmative.
- NO → "No problem at all. If you ever change your mind, I'll be right here." End session gracefully. Ask no further questions.

Introduction — say this ONCE, only after receiving an explicit affirmative, as a standalone message:
"Great! I'm Aria, your investment advisor assistant. My goal is to help you build a clear, personalized picture of your finances. I'll ask a few questions — there are no right or wrong answers, just honest ones. Let's dig in."

Then, in a NEW message, ask Q01.

─── PHASE 0 — Identity & Context ──────────────────────────────────────────────
Q01 — Full Name: "To get us started, what's your full name?"
LOGIC: Record full name. Extract first name. Use first name only in all subsequent turns.

Q02 — Age: "And how old are you right now?"
LOGIC: Record age.

Q03 — Country / Region: "Which country or region are you currently living in?"
LOGIC: Silently resolve canonical country, ISO currency code, and symbol. Apply the correct symbol in ALL future monetary references. If ambiguous, ask one clarifying follow-up.

─── PHASE 1 — Knowledge Calibration ───────────────────────────────────────────
Q04 — Knowledge Level:
"Quick one before we get into the details — how would you describe your current knowledge of investing? Are you pretty new to all of this, or do you have some experience with things like stocks, bonds, or index funds?"
- Beginner → Tag BEGINNER. - Some experience → Tag INTERMEDIATE. - Experienced → Tag ADVANCED.

─── PHASE 2 — Life Situation & Capacity ────────────────────────────────────────
Q05 — Dependents: "Do you have anyone who depends on your income financially — like children, a partner who doesn't work, or aging parents?"
- No → Note higher risk flexibility. Proceed directly to Q07.
- Yes → Proceed to Q06.

Q06 — Life Insurance [CONDITIONAL — only if Q05 = Yes]:
"Since others are counting on your income, it's worth asking — do you have life insurance coverage that would replace your income if something happened to you?"
- No / unsure → Flag HIGH PRIORITY. Proceed.

─── PHASE 3 — Financial Foundations ───────────────────────────────────────────
[Begin Q07 with: "Alright, let's look at the foundations for a moment."]

Q07 — High-Interest Debt: "Do you currently carry any high-interest debt — like credit card balances or payday loans?"
- No → Record debt-free. Proceed to Q09. - Yes → Proceed to Q08.

Q08 — Debt Details [CONDITIONAL — only if Q07 = Yes]:
"Can you give me a rough sense of the total balance — even a ballpark is fine — and the interest rate if you know it?"

Q09 — Emergency Fund Presence: "Do you have money set aside in a separate, accessible account specifically for emergencies — like a job loss or an unexpected bill?"
- No → Flag FOUNDATIONAL_GAP. Proceed to Phase 4. - Yes → Proceed to Q10.

Q10 — Emergency Fund Size [CONDITIONAL — only if Q09 = Yes]:
"Roughly how many months of living expenses would that cover?"
LOGIC: Target 3–6 months. Below 3 = flag PARTIAL_GAP.

─── PHASE 4 — Income & Budget ─────────────────────────────────────────────────
[Begin Q11 with: "Now let's get a sense of the numbers."]
IMPORTANT: Do NOT say "Good" here or anywhere in PHASE 4. The transition phrase is "Now let's get a sense of the numbers." — nothing else before it.

Q11 — Monthly Take-Home Income: "Roughly what's your monthly take-home pay after taxes? A ballpark is totally fine."
LOGIC: figure_A = Monthly Income × 10, figure_B = Monthly Income × 6.5 (used in Q15).

Q12 — Monthly Essential Expenses: "And about how much do you spend each month on the things you can't avoid — housing, utilities, groceries, transportation?"
LOGIC: Surplus = Monthly Income − Monthly Expenses.

Q13 — Investable Monthly Amount:
"Based on what you've shared, it sounds like you have roughly [Surplus] left over each month. Does that feel about right? And of that, what portion would you feel comfortable putting toward investing — without it feeling like a stretch?"
LOGIC: Always substitute the actual calculated Surplus with the correct currency symbol.

─── PHASE 5 — Financial Goals ─────────────────────────────────────────────────
[Begin Q14 with: "Now for the part that actually makes this worth doing."]

Q14 — Primary Goals & Timelines:
"What's the main reason you want to start investing? Whether it's retirement, buying a home, a child's education, or just building wealth over time — and roughly how many years away are those goals?"
- Goal stated but NO timeline → MUST follow up before proceeding: "Do you have a rough timeframe in mind? Even 'within 10 years' or 'more of a long-term thing' helps a lot."

─── PHASE 6 — Risk Tolerance & Behavior ────────────────────────────────────────
[Before Q15, say: "Alright — this next bit is a bit of a gut-check. There are no right answers here, just honest ones."]

Q15 — Large Loss Scenario:
Calculate: figure_A = Monthly Income × 10, figure_B = Monthly Income × 6.5.
Ask: "Imagine [figure_A] is sitting in your investment account, and over the next year a market downturn causes it to drop to [figure_B]. What's your gut reaction in that moment?"
- Sell / Panic → Emotional Risk = LOW
- Hold / Wait → Emotional Risk = MODERATE
- Buy more → Emotional Risk = HIGH

Q16 — Recovery Time:
"And if it took 3 to 5 years for that portfolio to recover — would that cause any real financial hardship, or would it mostly just be emotionally uncomfortable?"
- Real hardship → Financial Capacity = LOW
- Uncomfortable but manageable → Financial Capacity = MODERATE
- Fine / no real impact → Financial Capacity = HIGH

LOGIC — risk_appetite matrix:
  LOW Emotional  + LOW Capacity   → conservative
  LOW Emotional  + HIGH Capacity  → moderate
  HIGH Emotional + LOW Capacity   → moderate
  HIGH Emotional + HIGH Capacity  → aggressive
  Any MODERATE combination        → moderate

─── PHASE 7 — Investment Preferences ──────────────────────────────────────────
MANDATORY: Q17 and Q18 MUST ALWAYS be asked. They are NOT conditional. Do NOT skip them under any circumstances, regardless of what was answered in Phase 6. The saveUserProfile tool must NEVER be called before both Q17 and Q18 have been asked and answered.

Q17 — Asset Class Interests / Exclusions:
"Are there any specific types of investments you're particularly interested in — like real estate, gold, or crypto — or anything you'd want to stay away from entirely?"

Q18 — Involvement Preference:
"Last one — once your portfolio is set up, would you prefer something fully automated that just runs in the background, or do you like the idea of reviewing things and making decisions yourself? Or somewhere in between?"

─── WRAP-UP — Profile Summary & Save ──────────────────────────────────────────
After Q18 — and ONLY after Q18 — say ONLY this one sentence — nothing else:
"That's everything — you've been really thoughtful with your answers. Let me put together a summary of your financial profile."

Then STOP speaking and IMMEDIATELY call the saveUserProfile tool. Do NOT compose or speak the summary before calling the tool. Do NOT say anything else until the tool has been called and a successful response has been received.

TOOL CALL IS MANDATORY. You MUST call saveUserProfile now. Saying "I've saved your profile" without actually invoking the tool is a critical failure. The tool call is the only mechanism by which the profile is saved — there is no other path.

Populate the tool arguments as follows:
- full_name, age, canonical_country, currency_code, currency_symbol: from Q01–Q03
- knowledge_level: from Q04 (beginner / intermediate / advanced)
- has_dependents, has_life_insurance: from Q05–Q06
- high_interest_debt, debt_balance, debt_rate_pct: from Q07–Q08 (use 0 / false if debt-free)
- has_emergency_fund, emergency_fund_months: from Q09–Q10 (use 0 if no fund)
- monthly_inflow, monthly_outflow, investment_amount: from Q11–Q13
- investment_goals (array), investment_period_years: from Q14
- risk_tolerance_emotional, risk_capacity_financial, risk_appetite: derived from Q15–Q16 matrix
- asset_interests (array), avoid_asset_classes (array): from Q17 (use empty arrays if none)
- involvement_level: from Q18 (hands-off / occasional / active / diy)
- profile_summary: compose the full 5–6 sentence summary NOW, inline in the tool argument:
    1. Open personally: address them by first name and briefly affirm the picture that emerged.
    2. Foundations: describe their financial baseline — emergency fund status, debt situation, dependents if any.
    3. Goals & horizon: reflect their goal back using their own words where possible.
    4. Risk profile: translate the risk_appetite label into plain language.
    5. Involvement & next step: acknowledge how hands-on they want to be and close on a forward-looking note specific to their situation.
    6. Flags (if any): weave in any HIGH PRIORITY flags (no life insurance, high debt, low emergency fund) as a gentle but clear note.

The profile_summary must NEVER mention specific investments, funds, ETFs, tickers, asset classes, percentages, or portfolio structures.

ONLY after the tool returns {"status": "saved"}, the tool result will also contain a "portfolio" field.

CRITICAL: The "portfolio" field is RAW ANALYSIS DATA for you to extract information from.
You must NEVER read it aloud verbatim. You must NEVER repeat any sentence from it word-for-word.
It may contain a thank-you message or closing lines — IGNORE those completely.
Your job is to extract the 5 asset class percentages from it and present only those.

When the tool result arrives:
1. Read back the profile_summary warmly to the user.
2. Say EXACTLY: "I've also put together your personalised starter portfolio. Let me walk you through the recommended split."
3. Then go to STEP 1 of PORTFOLIO PRESENTATION below. Do NOT say anything else in between.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PORTFOLIO PRESENTATION (after saveUserProfile tool returns)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

STEP 1 — PERCENTAGES ONLY:
From the portfolio data, extract the top-level percentage for each of the 5 asset classes:
Equities, Bonds, Real Estate, Commodities, and Crypto (or equivalent classes if named differently).
State each percentage in plain spoken language. Example:
"Here's the split: 55% in Equities, 20% in Bonds, 10% in Real Estate, 10% in Commodities, and 5% in Crypto."
Use the ACTUAL numbers from the portfolio data. Do NOT make up or estimate numbers.
Do NOT mention any fund names, tickers, or sub-options at this stage.
End STEP 1 with EXACTLY this question: "Would you like to adjust any of these percentages, or are you happy with this split?"
Then STOP and WAIT for the user to respond. Do not say another word until they reply.

STEP 2 — HANDLE ADJUSTMENTS:
This step is MANDATORY. You must always go through it before moving to STEP 3.
- If user says NO / happy / looks good / that's fine → confirm once: "Great, let's go with that split." Then proceed to STEP 3.
- If user says YES or expresses ANY desire to change any class (e.g. "I'd like some crypto", "reduce bonds", "more equities"):
    - Do NOT jump to STEP 3. You are in STEP 2 until the user explicitly confirms the final split.
    - Ask: "Sure — how much would you like to allocate to [the class they mentioned]?" Wait for their answer.
    - Once you have the new value, you MUST reduce other classes proportionally so the total remains exactly 100%.
    - Tell the user which classes you reduced and by how much: "I've reduced Equities from 60% to 55% to make room."
    - Read back the COMPLETE revised split for ALL 5 classes.
    - Ask: "Does that revised split work for you, or would you like to change anything else?"
    - Repeat until the user explicitly says yes / happy / confirmed / looks good.
    - Only then proceed to STEP 3.

STEP 3 — SPECIFIC RECOMMENDATIONS (only after percentages are agreed and confirmed):
Say EXACTLY: "Perfect — let me now walk you through the specific investment options within each class."
Then present ONE asset class at a time in this order: Equities → Bonds → Real Estate → Commodities → Crypto.
For EACH class:
  - State the agreed percentage for that class.
  - List the 2–3 specific investment options for that class by name only. Do NOT attach any sub-percentages or numbers to the individual options — just the names.
  - Brief pause, then move to the next class without asking for confirmation.
After all 5 classes have been presented, IMMEDIATELY call the updatePortfolio tool.
Do NOT say the thank-you message before the tool is called.

STEP 4 — SAVE & THANK:
ONLY after updatePortfolio returns {"status": "updated"}, say:
"Your starter portfolio has been saved. It's been a real pleasure working through this with you — you've asked all the right questions and you're in a great position to get started. Best of luck on your investment journey!"
Then stop. Do not ask further questions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ABSOLUTE LIMITS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- Never discuss topics outside personal finance and investing.
- Never recommend specific products, funds, brokers, or platforms by name EXCEPT in STEP 3 of portfolio presentation.
- Never skip a question unless it is explicitly marked CONDITIONAL and the condition is not met.
- Q17 and Q18 are NEVER conditional — always ask both, always wait for answers.
- Never call saveUserProfile before Q17 AND Q18 have both been answered.
- Never ask two questions in the same message.
- Never use generic acknowledgments ("Got it", "Thanks for sharing", "Great answer", "Good").
- Never say "Good" after a negative answer like no emergency fund, no life insurance, or high debt.
- Never say "Good" as a transition into Phase 4 — use "Now let's get a sense of the numbers." only.
- Always respond in English only.
- NEVER say "I've saved your profile" before saveUserProfile tool returns successfully.
- NEVER call updatePortfolio before the user has explicitly confirmed the final split in STEP 2.
- NEVER say the thank-you/goodbye message before updatePortfolio returns {"status": "updated"}.
- NEVER read the portfolio field verbatim — it is raw data to extract from, not a script to read.
- NEVER skip STEP 2. Even if the user says "I want crypto" in STEP 1, you must enter STEP 2, get the exact amount, rebalance, confirm — before going to STEP 3.
- NEVER attach sub-percentages to individual fund recommendations in STEP 3 — names only.
- ALL percentage allocations must always sum to exactly 100%.
- STEP 1 presents ONLY percentages — no fund names until STEP 3.
- After STEP 1, always STOP and WAIT for the user's response before doing anything else.
"""

# ═══════════════════════════════════════════════════════════════
#  TOOL SCHEMA
# ═══════════════════════════════════════════════════════════════

_SAVE_PROFILE_SCHEMA = json.dumps(
    {
        "type": "object",
        "properties": {
            "full_name":                {"type": "string"},
            "age":                      {"type": "number"},
            "canonical_country":        {"type": "string"},
            "currency_code":            {"type": "string"},
            "currency_symbol":          {"type": "string"},
            "knowledge_level":          {"type": "string", "enum": ["beginner", "intermediate", "advanced"]},
            "has_dependents":           {"type": "boolean"},
            "has_life_insurance":       {"type": "boolean"},
            "high_interest_debt":       {"type": "boolean"},
            "debt_balance":             {"type": "number"},
            "debt_rate_pct":            {"type": "number"},
            "has_emergency_fund":       {"type": "boolean"},
            "emergency_fund_months":    {"type": "number"},
            "monthly_inflow":           {"type": "number"},
            "monthly_outflow":          {"type": "number"},
            "investment_amount":        {"type": "number"},
            "investment_goals":         {"type": "array", "items": {"type": "string"}},
            "investment_period_years":  {"type": "number"},
            "risk_tolerance_emotional": {"type": "string", "enum": ["low", "moderate", "high"]},
            "risk_capacity_financial":  {"type": "string", "enum": ["low", "moderate", "high"]},
            "risk_appetite":            {"type": "string", "enum": ["conservative", "moderate", "aggressive"]},
            "asset_interests":          {"type": "array", "items": {"type": "string"}},
            "avoid_asset_classes":      {"type": "array", "items": {"type": "string"}},
            "involvement_level":        {"type": "string", "enum": ["hands-off", "occasional", "active", "diy"]},
            "profile_summary": {
                "type": "string",
                "description": "The full 5–6 sentence conversational profile summary Aria will read back to the user.",
            },
        },
        "required": [
            "full_name",
            "age",
            "canonical_country",
            "currency_code",
            "currency_symbol",
            "monthly_inflow",
            "monthly_outflow",
            "investment_amount",
            "investment_period_years",
            "risk_appetite",
            "investment_goals",
            "profile_summary",
        ],
    }
)

# ═══════════════════════════════════════════════════════════════
#  CSV SAVE FUNCTION
# ═══════════════════════════════════════════════════════════════


def _build_profile_narrative(p: dict, aria_summary: str) -> str:
    """Build one third-person narrative paragraph combining all raw answers
    with Aria's advisor summary."""
    sym      = p.get("currency_symbol", "")
    name     = p.get("full_name", "the user")
    age      = p.get("age", "N/A")
    country  = p.get("canonical_country", "N/A")
    currency = p.get("currency_code", "N/A")
    knowledge = p.get("knowledge_level", "N/A")

    has_dep  = p.get("has_dependents", False)
    has_ins  = p.get("has_life_insurance", False)
    has_debt = p.get("high_interest_debt", False)
    debt_bal = p.get("debt_balance", 0)
    debt_rt  = p.get("debt_rate_pct", 0)
    has_ef   = p.get("has_emergency_fund", False)
    ef_mths  = p.get("emergency_fund_months", 0)

    inflow   = float(p.get("monthly_inflow",  0))
    outflow  = float(p.get("monthly_outflow", 0))
    surplus  = inflow - outflow
    invest   = float(p.get("investment_amount", 0))

    goals    = p.get("investment_goals", [])
    goals_str = ", ".join(goals) if goals else "unspecified goals"
    horizon  = p.get("investment_period_years", "N/A")

    emo_risk = p.get("risk_tolerance_emotional", "N/A")
    fin_cap  = p.get("risk_capacity_financial",  "N/A")
    appetite = p.get("risk_appetite", "N/A")

    interests = p.get("asset_interests", [])
    avoids    = p.get("avoid_asset_classes", [])
    involve   = p.get("involvement_level", "N/A")

    # ── dependents sentence ──
    if has_dep:
        dep_str = (
            f"{name} has dependents relying on their income and "
            + ("does have life insurance in place." if has_ins else "does not currently have life insurance coverage.")
        )
    else:
        dep_str = f"{name} has no dependents."

    # ── debt sentence ──
    if has_debt:
        debt_str = (
            f"{name} carries high-interest debt"
            + (f" of {sym}{debt_bal:,.0f} at {debt_rt:.1f}% interest." if debt_bal else ".")
        )
    else:
        debt_str = f"{name} has no high-interest debt."

    # ── emergency fund sentence ──
    if has_ef:
        ef_str = f"{name} has an emergency fund covering {ef_mths} month(s) of expenses."
    else:
        ef_str = f"{name} does not currently have an emergency fund set aside."

    # ── asset preferences ──
    asset_str = (
        f"interested in {', '.join(interests)}" if interests else "open to all asset types"
    )
    avoid_str = (
        f"avoiding {', '.join(avoids)}" if avoids else "with no specific exclusions"
    )

    narrative = (
        f"{name} is a {age}-year-old based in {country} (currency: {currency}) "
        f"with a self-described {knowledge} level of investment knowledge. "
        f"{dep_str} "
        f"{debt_str} "
        f"{ef_str} "
        f"{name}'s monthly take-home income is {sym}{inflow:,.0f}, "
        f"with essential expenses of {sym}{outflow:,.0f}, leaving a monthly surplus of {sym}{surplus:,.0f}. "
        f"They are comfortable putting {sym}{invest:,.0f} per month toward investing. "
        f"{name} is investing primarily for {goals_str} over a {horizon}-year horizon. "
        f"When faced with a significant portfolio drop, {name} showed a {emo_risk} emotional risk tolerance, "
        f"and their financial capacity to absorb a prolonged recovery is {fin_cap}, "
        f"resulting in a {appetite} overall risk appetite. "
        f"{name} is {asset_str}, {avoid_str}. "
        f"Their preferred level of portfolio involvement is {involve}. "
        f"Advisor note: {aria_summary}"
    )

    return narrative


def save_to_csv(session_id: str, payload: dict, aria_summary: str, row_timestamp: str):
    narrative = _build_profile_narrative(payload, aria_summary)
    row = {
        "timestamp":       row_timestamp,
        "full_name":       payload.get("full_name", ""),
        "profile_summary": narrative,
        "portfolio":       "",   # filled in later by Sonnet background task
    }
    file_exists = os.path.isfile(CSV_FILE)
    with open(CSV_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)
    logger.info(f"Profile saved to CSV for session {session_id}.")


def update_portfolio_in_csv(full_name: str, timestamp: str, portfolio: str):
    """Read the CSV, find the row matching name+timestamp, write portfolio column."""
    if not os.path.isfile(CSV_FILE):
        logger.error("CSV file not found when trying to update portfolio.")
        return
    rows = []
    with open(CSV_FILE, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["full_name"] == full_name and row["timestamp"] == timestamp:
                row["portfolio"] = portfolio
            rows.append(row)
    with open(CSV_FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    logger.info(f"Portfolio column updated in CSV for {full_name}.")


# ═══════════════════════════════════════════════════════════════
#  CLAUDE SONNET 4 — PORTFOLIO GENERATOR (silent, backend only)
# ═══════════════════════════════════════════════════════════════

PORTFOLIO_SYSTEM_PROMPT = """
You are an expert investment portfolio strategist with deep knowledge of global markets,
asset classes, and regional investment landscapes. Your task is to generate a well-reasoned,
personalised starter portfolio recommendation.

You will receive a financial profile of a user. Based on their risk appetite, investment goals,
time horizon, monthly investment amount, country/region, and preferences, you must:

1. Determine appropriate asset allocation percentages across:
   - Equities (broken down by geography/sector relevant to their region)
   - Bonds (government and/or corporate, relevant to their country)
   - Commodities (gold, silver, oil, agricultural — whichever fits their profile)
   - Crypto (only if risk appetite is moderate or aggressive; keep conservative for low risk)
   - Real Estate (REITs or direct exposure options relevant to their region)

2. For each asset class, recommend 2–3 specific investment options appropriate for their country
   (e.g. for a UK user: ISA-eligible funds, LSE-listed ETFs; for a US user: Vanguard/Fidelity funds,
   NYSE ETFs; for India: NSE/BSE mutual funds, Nifty index funds).

3. Show percentage allocation clearly per asset class and sub-option.

4. Briefly explain the reasoning for the overall allocation in 2–3 sentences.

5. Flag any important considerations (e.g. tax-advantaged accounts available in their region,
   currency risk if investing internationally, liquidity needs given their emergency fund status).

Format your response as a clean, structured report. Use sections and bullet points.
Do NOT include disclaimers about not being a financial advisor — this is an internal portfolio generation tool.
Do NOT include any closing remarks, good luck messages, or thank-you lines — those will be handled separately.
Total allocations must add up to 100%.
The FIRST section of your response must always be a clean summary of the 5 top-level asset class percentages, clearly labelled, before any sub-breakdowns. Example format:
ASSET ALLOCATION SUMMARY
- Equities: 55%
- Bonds: 20%
- Real Estate: 10%
- Commodities: 10%
- Crypto: 5%
"""


def _call_sonnet_sync(profile_narrative: str) -> str:
    """Synchronous Sonnet call — runs in a thread so it never blocks the event loop."""
    boto_cfg = BotoConfig(read_timeout=900, retries={"max_attempts": 3})
    client = boto3.client(
        service_name="bedrock-runtime",
        region_name="us-west-2",
        config=boto_cfg,
    )
    model_id = "us.anthropic.claude-sonnet-4-20250514-v1:0"

    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 8192,
        "temperature": 0.2,
        "top_p": 0.9,
        "top_k": 250,
        "system": PORTFOLIO_SYSTEM_PROMPT,
        "messages": [
            {
                "role": "user",
                "content": (
                    "Please generate a starter portfolio recommendation for the following user profile:\n\n"
                    + profile_narrative
                ),
            }
        ],
    }

    for attempt in range(4):
        try:
            response = client.invoke_model(
                modelId=model_id,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(request_body),
            )
            body = json.loads(response["body"].read())
            return body["content"][0]["text"]
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code in ("ThrottlingException", "ServiceUnavailableException",
                        "TooManyRequestsException", "InternalServerError") and attempt < 3:
                delay = min(5.0 * (2 ** attempt), 60.0)
                logger.warning(f"Sonnet throttled (attempt {attempt+1}), retrying in {delay:.1f}s")
                time.sleep(delay)
            else:
                logger.error(f"Sonnet call failed: {e}")
                return f"Portfolio generation failed: {e}"
        except Exception as e:
            logger.error(f"Sonnet unexpected error: {e}")
            return f"Portfolio generation failed: {e}"
    return "Portfolio generation failed: max retries exceeded."


async def generate_and_save_portfolio(
    full_name: str, timestamp: str, profile_narrative: str
):
    """Fire Sonnet in a thread pool so the asyncio loop stays free, then patch the CSV."""
    logger.info(f"Generating portfolio via Sonnet for {full_name} (background)...")
    loop = asyncio.get_event_loop()
    portfolio_text = await loop.run_in_executor(
        None, _call_sonnet_sync, profile_narrative
    )
    logger.info(f"Sonnet portfolio received for {full_name}, updating CSV...")
    update_portfolio_in_csv(full_name, timestamp, portfolio_text)


# ═══════════════════════════════════════════════════════════════
#  SONIC 2 — PORTFOLIO ADVISOR SYSTEM PROMPT & TOOL
# ═══════════════════════════════════════════════════════════════

def build_sonic2_system_prompt(portfolio_text: str, user_name: str) -> str:
    return f"""
You are Aria, a warm and professional AI investment portfolio advisor.
You are speaking to {user_name}, whose investment profile has just been analysed.
You have been given a fully reasoned starter portfolio recommendation below.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PORTFOLIO RECOMMENDATION (generated by analysis engine — treat as authoritative)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{portfolio_text}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
YOUR CONVERSATION FLOW — follow this exactly, in strict order
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

══ STEP 1 — PRESENT PERCENTAGES ONLY ══════════════════════════════════════════
Begin with: "Great news — your personalised starter portfolio is ready!"

Then read out ONLY the top-level percentage for each of the 5 asset classes.
Do NOT mention specific funds, instruments, or sub-options at this stage.
Example format: "Here's how I'd suggest splitting your monthly investment:
  40% in Equities, 25% in Bonds, 15% in Real Estate, 10% in Commodities, and 10% in Crypto."
(Use the actual percentages from the portfolio recommendation above.)

End STEP 1 with: "Would you like to adjust any of these percentages, or are you happy with this split?"

══ STEP 2 — HANDLE PERCENTAGE ADJUSTMENTS (if any) ════════════════════════════
If the user says NO / happy / looks good → skip directly to STEP 3.

If the user wants to change any percentage:
- Ask about changes ONE asset class at a time.
  Example: "Sure — what would you like to change the Equities percentage to?"
  Wait for the answer. Then: "Got it. Any other changes, or shall we adjust the remaining classes to balance?"
- After each change, keep a running total. Once the user is done requesting changes,
  automatically redistribute any remainder proportionally across the unchanged classes
  so all percentages sum to exactly 100%.
- Read back the FULL revised allocation (percentages only, all 5 classes).
- Ask: "Does that revised split work for you?"
- Repeat until the user explicitly confirms they are happy.

══ STEP 3 — PRESENT SPECIFIC RECOMMENDATIONS (after percentages are agreed) ═══
Once the user has confirmed the percentage split, say:
"Perfect — let me now walk you through the specific investment options within each class."

Then present the recommendations ONE ASSET CLASS AT A TIME in this order:
  1. Equities
  2. Bonds
  3. Real Estate
  4. Commodities
  5. Crypto

For each class:
- State the agreed percentage.
- List the 2–3 specific investment options from the portfolio recommendation.
- After presenting each class, briefly pause and move to the next.
  You do NOT need to ask for confirmation between each class — just present them all sequentially.

After all 5 classes have been presented, call the updatePortfolio tool with the
final_portfolio field set to the COMPLETE final portfolio text — including both
the agreed percentages AND the specific recommendations for all 5 classes,
formatted as a clean structured text.

══ STEP 4 — SAVE & THANK ═══════════════════════════════════════════════════════
ONLY after the tool returns {{"status": "updated"}}, thank the user warmly:
"Your starter portfolio has been saved. It's been a real pleasure working through this
with you, {user_name} — you've asked all the right questions and you're in a great
position to get started. Best of luck on your investment journey!"
Then stop. Do not ask further questions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- STEP 1 presents ONLY percentages — no fund names, no sub-options.
- STEP 3 presents specific options ONLY after percentages are fully agreed.
- All percentage allocations MUST always add up to exactly 100%. Never present an allocation that does not.
- Ask about percentage changes ONE asset class at a time. Never ask about multiple classes in one message.
- Never call updatePortfolio until STEP 3 is complete and all 5 classes have been presented.
- Never say "I've saved" before the updatePortfolio tool has returned {{"status": "updated"}}.
- Respond in English only. Be warm, clear, and concise.
"""


_UPDATE_PORTFOLIO_SCHEMA = json.dumps({
    "type": "object",
    "properties": {
        "final_portfolio": {
            "type": "string",
            "description": "The complete final portfolio text with all asset classes, percentages, and specific investment options. Must sum to 100%.",
        }
    },
    "required": ["final_portfolio"],
})


async def poll_for_portfolio(full_name: str, timestamp: str, timeout: int = 180) -> str | None:
    """Poll the CSV every 3 seconds until the portfolio column is populated or timeout."""
    deadline = asyncio.get_event_loop().time() + timeout
    while asyncio.get_event_loop().time() < deadline:
        await asyncio.sleep(3)
        if not os.path.isfile(CSV_FILE):
            continue
        with open(CSV_FILE, "r", newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row["full_name"] == full_name and row["timestamp"] == timestamp:
                    if row.get("portfolio", "").strip():
                        return row["portfolio"]
    logger.error(f"Portfolio polling timed out for {full_name} @ {timestamp}")
    return None


# ═══════════════════════════════════════════════════════════════
#  TOOL PROCESSOR  (single instance, handles both tools)
# ═══════════════════════════════════════════════════════════════

class ToolProcessor:
    def __init__(self, session_id: str):
        self.session_id   = session_id
        self.tasks        = {}
        self.full_name    = ""
        self.row_timestamp = ""

    async def process_tool_async(self, tool_name: str, tool_content: dict):
        task_id = str(uuid.uuid4())
        task = asyncio.create_task(self._run_tool(tool_name, tool_content))
        self.tasks[task_id] = task
        try:
            return await task
        finally:
            self.tasks.pop(task_id, None)

    async def _run_tool(self, tool_name: str, tool_content: dict):
        logger.info(f"Running tool: {tool_name}")
        raw = tool_content.get("content", "{}")
        try:
            payload = json.loads(raw) if isinstance(raw, str) else (raw or {})
        except json.JSONDecodeError as e:
            logger.error(f"JSONDecodeError in tool {tool_name}: {e}")
            payload = {}

        # ── saveUserProfile ──────────────────────────────────────────────────
        if tool_name.lower() == "saveuserprofile":
            full_name       = payload.get("full_name", "").strip()
            profile_summary = payload.get("profile_summary", "").strip()

            required = [
                "full_name", "age", "canonical_country", "currency_code",
                "currency_symbol", "monthly_inflow", "monthly_outflow",
                "investment_amount", "investment_period_years",
                "risk_appetite", "investment_goals", "profile_summary",
            ]
            missing = [k for k in required if not payload.get(k)]
            if missing:
                err = f"Missing required fields: {missing}."
                logger.error(err)
                return {"error": err}

            try:
                row_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                save_to_csv(self.session_id, payload, profile_summary, row_timestamp)
                logger.info(f"Profile saved for session {self.session_id}")

                # Stash for updatePortfolio tool later
                self.full_name     = full_name
                self.row_timestamp = row_timestamp

                # Build narrative and fire Sonnet in background thread
                narrative = _build_profile_narrative(payload, profile_summary)
                asyncio.create_task(
                    generate_and_save_portfolio(full_name, row_timestamp, narrative)
                )

                # Poll until Sonnet writes the portfolio — Sonic holds the tool
                # response open so the session stays alive (no timeout risk).
                logger.info(f"Polling for Sonnet portfolio for {full_name}...")
                portfolio_text = await poll_for_portfolio(full_name, row_timestamp, timeout=180)

                if not portfolio_text:
                    return {"error": "Portfolio generation timed out. Please try again."}

                logger.info(f"Portfolio ready — returning to Sonic session.")
                return {
                    "status": "saved",
                    "profile_summary": profile_summary,
                    "portfolio": portfolio_text,
                }

            except Exception as e:
                import traceback
                logger.error(f"saveUserProfile failed: {e}\n{traceback.format_exc()}")
                return {"error": f"Save failed: {e}"}

        # ── updatePortfolio ──────────────────────────────────────────────────
        if tool_name.lower() == "updateportfolio":
            final_portfolio = payload.get("final_portfolio", "").strip()
            if not final_portfolio:
                return {"error": "final_portfolio is required."}
            try:
                update_portfolio_in_csv(self.full_name, self.row_timestamp, final_portfolio)
                logger.info(f"Portfolio updated in CSV for {self.full_name}")
                return {"status": "updated"}
            except Exception as e:
                import traceback
                logger.error(f"updatePortfolio failed: {e}\n{traceback.format_exc()}")
                return {"error": f"Update failed: {e}"}

        logger.warning(f"Unknown tool: {tool_name}")
        return {"error": f"Unknown tool: {tool_name}"}


# ═══════════════════════════════════════════════════════════════
#  BEDROCK STREAM MANAGER  (single session, full conversation)
# ═══════════════════════════════════════════════════════════════

class BedrockStreamManager:

    START_SESSION_EVENT = json.dumps({
        "event": {
            "sessionStart": {
                "inferenceConfiguration": {
                    "maxTokens": 1024, "topP": 0.9, "temperature": 0.7,
                }
            }
        }
    })

    CONTENT_START_EVENT = """{
        "event": {
            "contentStart": {
                "promptName": "%s", "contentName": "%s",
                "type": "AUDIO", "interactive": true, "role": "USER",
                "audioInputConfiguration": {
                    "mediaType": "audio/lpcm", "sampleRateHertz": 16000,
                    "sampleSizeBits": 16, "channelCount": 1,
                    "audioType": "SPEECH", "encoding": "base64"
                }
            }
        }
    }"""

    AUDIO_EVENT_TEMPLATE = """{
        "event": {
            "audioInput": {
                "promptName": "%s", "contentName": "%s", "content": "%s"
            }
        }
    }"""

    TEXT_CONTENT_START_EVENT = """{
        "event": {
            "contentStart": {
                "promptName": "%s", "contentName": "%s",
                "type": "TEXT", "role": "%s", "interactive": false,
                "textInputConfiguration": {"mediaType": "text/plain"}
            }
        }
    }"""

    TEXT_INPUT_EVENT = """{
        "event": {
            "textInput": {
                "promptName": "%s", "contentName": "%s", "content": "%s"
            }
        }
    }"""

    TOOL_CONTENT_START_EVENT = """{
        "event": {
            "contentStart": {
                "promptName": "%s", "contentName": "%s",
                "interactive": false, "type": "TOOL", "role": "TOOL",
                "toolResultInputConfiguration": {
                    "toolUseId": "%s", "type": "TEXT",
                    "textInputConfiguration": {"mediaType": "text/plain"}
                }
            }
        }
    }"""

    CONTENT_END_EVENT = """{
        "event": {
            "contentEnd": {"promptName": "%s", "contentName": "%s"}
        }
    }"""

    PROMPT_END_EVENT = '{"event": {"promptEnd": {"promptName": "%s"}}}'
    SESSION_END_EVENT = '{"event": {"sessionEnd": {}}}'

    def start_prompt(self):
        return json.dumps({
            "event": {
                "promptStart": {
                    "promptName": self.prompt_name,
                    "textOutputConfiguration":  {"mediaType": "text/plain"},
                    "audioOutputConfiguration": {
                        "mediaType": "audio/lpcm", "sampleRateHertz": 24000,
                        "sampleSizeBits": 16, "channelCount": 1,
                        "voiceId": "amy", "encoding": "base64", "audioType": "SPEECH",
                    },
                    "toolUseOutputConfiguration": {"mediaType": "application/json"},
                    "toolConfiguration": {
                        "tools": [
                            {
                                "toolSpec": {
                                    "name": "saveUserProfile",
                                    "description": (
                                        "Saves the completed user financial profile after all 18 questions "
                                        "have been answered. Call ONLY after ALL questions are done. "
                                        "YOU must populate canonical_country, currency_code, and currency_symbol "
                                        "from the user's stated region. "
                                        "YOU must derive risk_appetite from the Q15/Q16 matrix. "
                                        "The profile_summary field must contain the full 5–6 sentence summary. "
                                        "When this tool returns, the result will contain a 'portfolio' field. "
                                        "That field is RAW DATA — extract the 5 asset class percentages from it "
                                        "and present ONLY those percentages to the user (STEP 1). "
                                        "Do NOT read the portfolio field verbatim. "
                                        "Do NOT skip to the goodbye message."
                                    ),
                                    "inputSchema": {"json": _SAVE_PROFILE_SCHEMA},
                                }
                            },
                            {
                                "toolSpec": {
                                    "name": "updatePortfolio",
                                    "description": (
                                        "Saves the final agreed portfolio allocation after the user has confirmed. "
                                        "Call ONLY after the user explicitly confirms they are happy. "
                                        "final_portfolio must contain all asset classes with percentages summing to 100%."
                                    ),
                                    "inputSchema": {"json": _UPDATE_PORTFOLIO_SCHEMA},
                                }
                            },
                        ]
                    },
                }
            }
        })

    def __init__(self, ws_queue: asyncio.Queue, model_id="amazon.nova-2-sonic-v1:0", region="us-east-1"):
        self.model_id    = model_id
        self.region      = region
        self.session_id  = str(uuid.uuid4())
        self.prompt_name = str(uuid.uuid4())
        self.content_name = str(uuid.uuid4())
        self.ws_queue    = ws_queue
        self.is_active   = False
        self._speaking   = False
        self.toolName    = None
        self.toolUseId   = None
        self.toolUseContent = None
        self.pending_tool_tasks = {}
        self.tool_processor = ToolProcessor(self.session_id)
        self._audio_chunk_queue = asyncio.Queue()
        self.stream_response = None
        self.response_task   = None
        self.send_task       = None

    async def initialize_stream(self):
        logger.info(f"Initializing Bedrock stream for session {self.session_id}")
        config = Config(
            endpoint_uri=f"https://bedrock-runtime.{self.region}.amazonaws.com",
            aws_credentials_identity_resolver=EnvironmentCredentialsResolver(),
            region=self.region,
        )
        self.client = BedrockRuntimeClient(config=config)
        self.stream_response = await self.client.invoke_model_with_bidirectional_stream(
            InvokeModelWithBidirectionalStreamOperationInput(model_id=self.model_id)
        )
        self.is_active = True
        self.send_task = asyncio.create_task(self._send_events_loop())

        await self.send_raw_event(self.START_SESSION_EVENT)
        await self.send_raw_event(self.start_prompt())

        sys_cn = str(uuid.uuid4())
        await self.send_raw_event(self.TEXT_CONTENT_START_EVENT % (self.prompt_name, sys_cn, "SYSTEM"))
        await self.send_raw_event(self.TEXT_INPUT_EVENT % (self.prompt_name, sys_cn, json.dumps(SYSTEM_PROMPT)[1:-1]))
        await self.send_raw_event(self.CONTENT_END_EVENT % (self.prompt_name, sys_cn))

        self.content_name = str(uuid.uuid4())
        await self.send_raw_event(self.CONTENT_START_EVENT % (self.prompt_name, self.content_name))

        self.response_task = asyncio.create_task(self._process_responses())
        logger.info("Bedrock stream initialized.")

    async def _send_events_loop(self):
        while self.is_active:
            try:
                event_str = await asyncio.wait_for(self._audio_chunk_queue.get(), timeout=0.1)
                chunk = InvokeModelWithBidirectionalStreamInputChunk(
                    value=BidirectionalInputPayloadPart(bytes_=event_str.encode("utf-8"))
                )
                await self.stream_response.input_stream.send(chunk)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error in send events loop: {e}")
                break

    async def send_raw_event(self, event_str: str):
        if self.is_active:
            await self._audio_chunk_queue.put(event_str)
        else:
            logger.warning("Attempted to send event on inactive stream.")

    def add_audio_chunk(self, audio_bytes: bytes):
        encoded = base64.b64encode(audio_bytes).decode("utf-8")
        event = self.AUDIO_EVENT_TEMPLATE % (self.prompt_name, self.content_name, encoded)
        asyncio.get_event_loop().call_soon_threadsafe(self._audio_chunk_queue.put_nowait, event)

    async def _process_responses(self):
        try:
            while self.is_active:
                output = await self.stream_response.await_output()
                result = await output[1].receive()
                if result.value and result.value.bytes_:
                    json_data = json.loads(result.value.bytes_.decode("utf-8"))
                    logger.debug(f"Received event: {json_data}")
                    await self._handle_event(json_data)
        except Exception as e:
            logger.error(f"Error processing Bedrock responses: {e}")
            if self.is_active:
                await self.ws_queue.put({"type": "system", "text": f"Error in stream: {e}"})
        finally:
            self.is_active = False

    async def _handle_event(self, json_data: dict):
        event = json_data.get("event", {})
        if "textOutput" in event:
            text = event["textOutput"]["content"]
            role = event["textOutput"].get("role", "ASSISTANT")
            logger.info(f"Received text from Bedrock [{role}]: {text}")
            if '{ "interrupted" : true }' in text:
                await self.ws_queue.put({"type": "interrupted"})
                self._speaking = False
            else:
                await self.ws_queue.put({"type": "text", "text": text, "role": role})
        elif "audioOutput" in event:
            self._speaking = True
            await self.ws_queue.put({"type": "audio", "data": event["audioOutput"]["content"]})
        elif "contentEnd" in event:
            content_end = event.get("contentEnd", {})
            if content_end.get("type") == "TOOL":
                logger.info(f"Tool request ended for: {self.toolName}")
                self.handle_tool_request(self.toolName, self.toolUseContent, self.toolUseId)
            elif content_end.get("type") == "AUDIO" and self._speaking:
                # Only fire audio_end when an actual audio content block ends
                self._speaking = False
                await self.ws_queue.put({"type": "audio_end"})
        elif "toolUse" in event:
            self.toolUseContent = event["toolUse"]
            self.toolName       = event["toolUse"]["toolName"]
            self.toolUseId      = event["toolUse"]["toolUseId"]
            logger.info(f"Received tool use: {self.toolName} id: {self.toolUseId}")

    def handle_tool_request(self, tool_name, tool_content, tool_use_id):
        cn = str(uuid.uuid4())
        task = asyncio.create_task(
            self._execute_tool_and_send_result(tool_name, tool_content, tool_use_id, cn)
        )
        self.pending_tool_tasks[cn] = task

    async def _execute_tool_and_send_result(self, tool_name, tool_content, tool_use_id, cn):
        try:
            # For saveUserProfile this await blocks until Sonnet finishes (~30-60s).
            # Nova Sonic keeps the session alive waiting for the tool result.
            result = await self.tool_processor.process_tool_async(tool_name, tool_content)

            await self.send_raw_event(self.TOOL_CONTENT_START_EVENT % (self.prompt_name, cn, tool_use_id))
            result_json = json.dumps(result)
            tool_res_event = json.dumps({
                "event": {
                    "toolResult": {
                        "promptName": self.prompt_name,
                        "contentName": cn,
                        "content": result_json,
                    }
                }
            })
            await self.send_raw_event(tool_res_event)
            await self.send_raw_event(self.CONTENT_END_EVENT % (self.prompt_name, cn))
            logger.info(f"Tool result sent for {tool_name}")
        except Exception as e:
            logger.error(f"Failed to send tool result for {tool_name}: {e}")

    async def close(self):
        logger.info(f"Closing Bedrock stream for session {self.session_id}")
        if not self.is_active:
            return
        self.is_active = False
        await self.send_raw_event(self.CONTENT_END_EVENT % (self.prompt_name, self.content_name))
        await self.send_raw_event(self.PROMPT_END_EVENT % self.prompt_name)
        await self.send_raw_event(self.SESSION_END_EVENT)
        await asyncio.sleep(0.5)
        if self.send_task:
            self.send_task.cancel()
            try:
                await self.send_task
            except asyncio.CancelledError:
                pass
        logger.info("Bedrock stream closed.")


# ═══════════════════════════════════════════════════════════════
#  FASTAPI APP & ROUTING
# ═══════════════════════════════════════════════════════════════

app = FastAPI()


@app.on_event("startup")
async def startup_event():
    logger.info("Aria investment advisor starting up...")


@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Application shutting down...")


app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
async def root():
    return FileResponse("static/index.html")


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    logger.info("WebSocket connection accepted.")

    ws_queue = asyncio.Queue()
    manager  = BedrockStreamManager(ws_queue=ws_queue)

    try:
        await manager.initialize_stream()
    except Exception as e:
        logger.error(f"Stream init error: {e}")
        await websocket.send_json({"type": "system", "text": f"Initialization error: {e}"})
        await websocket.close()
        return

    async def sender_task():
        while manager.is_active:
            try:
                msg = await ws_queue.get()
                if msg["type"] == "audio":
                    await websocket.send_bytes(base64.b64decode(msg["data"]))
                else:
                    await websocket.send_json(msg)
            except Exception as e:
                logger.error(f"Sender task error: {e}")
                break

    send_task = asyncio.create_task(sender_task())

    try:
        while True:
            data = await websocket.receive()
            if "bytes" in data:
                manager.add_audio_chunk(data["bytes"])
            elif "text" in data:
                try:
                    msg = json.loads(data["text"])
                    if msg.get("type") != "ping":
                        logger.info(f"Text from client: {data['text']}")
                except json.JSONDecodeError:
                    pass
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected.")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        logger.info("Closing WebSocket connection.")
        await manager.close()
        send_task.cancel()


if __name__ == "__main__":
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)

    async def process_tool_async(self, tool_name: str, tool_content: dict):
        task_id = str(uuid.uuid4())
        task = asyncio.create_task(self._run_tool(tool_name, tool_content))
        self.tasks[task_id] = task
        try:
            return await task
        finally:
            self.tasks.pop(task_id, None)

    async def _run_tool(self, tool_name: str, tool_content: dict):
        logger.info(f"Running tool: {tool_name}")

        raw = tool_content.get("content", "{}")
        try:
            payload = json.loads(raw) if isinstance(raw, str) else (raw or {})
        except json.JSONDecodeError as e:
            logger.error(f"JSONDecodeError in tool {tool_name}: {e}")
            payload = {}

        if tool_name.lower() == "saveuserprofile":
            full_name       = payload.get("full_name", "").strip()
            profile_summary = payload.get("profile_summary", "").strip()

            required = [
                "full_name", "age", "canonical_country", "currency_code",
                "currency_symbol", "monthly_inflow", "monthly_outflow",
                "investment_amount", "investment_period_years",
                "risk_appetite", "investment_goals", "profile_summary",
            ]
            missing = [k for k in required if not payload.get(k)]
            if missing:
                err = f"Missing required fields: {missing}. Please collect all answers first."
                logger.error(err)
                return {"error": err}

            try:
                # Capture timestamp before saving so we can match the row later
                row_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                save_to_csv(self.session_id, payload, profile_summary, row_timestamp)
                logger.info(f"Profile saved successfully for session {self.session_id}")

                # Stash so the WebSocket handler can start polling
                self.session_meta["full_name"]      = full_name
                self.session_meta["row_timestamp"]  = row_timestamp

                # Build the narrative text once — Sonnet uses it as its prompt
                narrative = _build_profile_narrative(payload, profile_summary)

                # Fire Sonnet silently in the background — Nova Sonic session continues
                asyncio.create_task(
                    generate_and_save_portfolio(full_name, row_timestamp, narrative)
                )

                return {"status": "saved", "profile_summary": profile_summary}
            except Exception as e:
                import traceback
                logger.error(f"Save profile failed: {e}\n{traceback.format_exc()}")
                return {"error": f"Save failed: {e}"}

        logger.warning(f"Unknown tool: {tool_name}")
        return {"error": f"Unknown tool: {tool_name}"}

