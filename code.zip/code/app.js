import * as THREE from 'three';
import { TalkingHead } from 'talkinghead';
import { LipsyncEn } from './lipsync-en.mjs';

let avatar, websocket, audioCtx, micStream, workletNode;
let isStreaming = false;
let keepAliveInterval = null;

const lipsync = new LipsyncEn();

const avatarView   = document.getElementById('avatar-view');
const startStopBtn = document.getElementById('start-stop-btn');
const clearLogBtn  = document.getElementById('clear-log-btn');
const statusDiv    = document.getElementById('status');
const chatLog      = document.getElementById('chat-log');

// ─── AUDIO CONVERSION ────────────────────────────────────────────────────────

function pcmToAudioBuffer(pcmInt16Array, sampleRate) {
    const ctx = avatar.audioCtx;
    const float32 = new Float32Array(pcmInt16Array.length);
    for (let i = 0; i < pcmInt16Array.length; i++) {
        float32[i] = pcmInt16Array[i] / 32768.0;
    }
    const audioBuffer = ctx.createBuffer(1, float32.length, sampleRate);
    audioBuffer.copyToChannel(float32, 0);
    return audioBuffer;
}

// ─── LIPSYNC BUILDER ─────────────────────────────────────────────────────────

function buildSpeakAudioObj(audioBuffer, text) {
    const durationMs = audioBuffer.duration * 1000;

    const preprocessed = lipsync.preProcessText(text);
    const wordList = preprocessed.split(/\s+/).filter(Boolean);

    if (wordList.length === 0) {
        return { audio: audioBuffer };
    }

    const wordData    = wordList.map(w => lipsync.wordsToVisemes(w));
    const wordRelDurs = wordData.map(r =>
        r.durations.length > 0 ? r.durations.reduce((a, b) => a + b, 0) : 1
    );

    const spacingUnits  = Math.max(0, wordList.length - 1);
    const totalRelUnits = wordRelDurs.reduce((a, b) => a + b, 0) + spacingUnits;
    const msPerUnit     = durationMs / (totalRelUnits || 1);
    const spacingMs     = msPerUnit;

    const words = [], wtimes = [], wdurations = [];
    const visemes = [], vtimes = [], vdurations = [];

    let wordStartMs = 0;

    wordData.forEach((r, wi) => {
        const wordMs = wordRelDurs[wi] * msPerUnit;

        words.push(wordList[wi]);
        wtimes.push(Math.round(wordStartMs));
        wdurations.push(Math.round(wordMs));

        r.visemes.forEach((v, vi) => {
            visemes.push(v);
            vtimes.push(Math.round(wordStartMs + r.times[vi] * msPerUnit));
            vdurations.push(Math.max(20, Math.round(r.durations[vi] * msPerUnit)));
        });

        wordStartMs += wordMs + (wi < wordData.length - 1 ? spacingMs : 0);
    });

    return { audio: audioBuffer, words, wtimes, wdurations, visemes, vtimes, vdurations };
}

// ─── SEQUENTIAL SPEAK QUEUE ──────────────────────────────────────────────────
// Each entry: { pcm: Int16Array, text: string }
// We only call speakAudio for the next entry AFTER the current one resolves.
// This prevents collisions that cause lipsync dropout mid-sentence.

const speakQueue = [];
let speakBusy    = false;

async function enqueueSpeech(pcmInt16Array, text) {
    speakQueue.push({ pcm: pcmInt16Array, text });
    if (!speakBusy) drainSpeakQueue();
}

async function drainSpeakQueue() {
    if (speakBusy || speakQueue.length === 0) return;
    speakBusy = true;

    while (speakQueue.length > 0) {
        const { pcm, text } = speakQueue.shift();
        try {
            await avatar.audioCtx.resume();
            const audioBuffer = pcmToAudioBuffer(pcm, 24000);
            const audioObj = (text && text.trim())
                ? buildSpeakAudioObj(audioBuffer, text)
                : { audio: audioBuffer };
            // speakAudio resolves only when the avatar FINISHES speaking —
            // so awaiting it serialises playback correctly.
            await avatar.speakAudio(audioObj);
        } catch (err) {
            console.error('[speakQueue] error:', err);
        }
    }

    speakBusy = false;
}

// ─── FALLBACK AUDIO (no avatar) ──────────────────────────────────────────────

let fallbackCtx    = null;
let audioQueue     = [];
let isPlayingAudio = false;

function getFallbackCtx() {
    if (!fallbackCtx || fallbackCtx.state === 'closed') {
        fallbackCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 24000 });
    }
    return fallbackCtx;
}

async function playNextInQueue() {
    if (isPlayingAudio || audioQueue.length === 0) return;
    isPlayingAudio = true;
    const pcmChunk = audioQueue.shift();
    try {
        const ctx = getFallbackCtx();
        await ctx.resume();
        const float32 = new Float32Array(pcmChunk.length);
        for (let i = 0; i < pcmChunk.length; i++) float32[i] = pcmChunk[i] / 32768.0;
        const buf    = ctx.createBuffer(1, float32.length, 24000);
        buf.copyToChannel(float32, 0);
        const source = ctx.createBufferSource();
        source.buffer = buf;
        source.connect(ctx.destination);
        source.onended = () => { isPlayingAudio = false; playNextInQueue(); };
        source.start(0);
    } catch (err) {
        console.error('Fallback audio error:', err);
        isPlayingAudio = false;
        playNextInQueue();
    }
}

// ─── AVATAR INIT ─────────────────────────────────────────────────────────────

async function initAvatar() {
    avatar = new TalkingHead(avatarView, {
        cameraView:    'upper',
        ttsEndpoint:   null,
        pcmSampleRate: 24000,
        lipsyncLang:   'en'
    });

    try {
        await avatar.showAvatar({ url: '/static/aria.glb' }, (ev) => {
            if (ev.lengthComputable) {
                statusDiv.innerText = `Loading Avatar: ${Math.round((ev.loaded / ev.total) * 100)}%`;
            }
        });
        statusDiv.innerText   = 'Avatar Ready. Click Start.';
        startStopBtn.disabled = false;
    } catch (error) {
        console.error('Error loading avatar:', error);
        statusDiv.innerText   = 'Avatar failed to load. Voice-only mode available.';
        startStopBtn.disabled = false;
    }
}

// ─── CHAT LOG ────────────────────────────────────────────────────────────────

let lastLoggedText = '';

function logChat(text, role = 'Aria') {
    const trimmed = text && text.trim();
    if (!trimmed) return;
    if (role === 'Aria' && trimmed === lastLoggedText) {
        console.warn('Duplicate suppressed:', trimmed.substring(0, 60));
        return;
    }
    if (role === 'Aria') lastLoggedText = trimmed;
    const div = document.createElement('div');
    div.className = `chat-message ${role}`;
    div.innerHTML = `<strong>${role}:</strong> ${trimmed}`;
    chatLog.appendChild(div);
    chatLog.scrollTop = chatLog.scrollHeight;
}

// ─── SESSION ─────────────────────────────────────────────────────────────────

async function toggleSession() {
    if (isStreaming) { stopSession(); return; }

    startStopBtn.disabled  = true;
    startStopBtn.innerText = 'Connecting...';

    try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
        await audioCtx.resume();

        if (avatar && avatar.audioCtx) await avatar.audioCtx.resume();

        micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const source = audioCtx.createMediaStreamSource(micStream);

        await audioCtx.audioWorklet.addModule('/static/audio-worklet-processor.js');
        workletNode = new AudioWorkletNode(audioCtx, 'audio-sender-processor');

        source.connect(workletNode);
        workletNode.connect(audioCtx.destination);

        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        websocket = new WebSocket(`${protocol}//${window.location.host}/ws`);
        websocket.binaryType = 'arraybuffer';

        websocket.onopen = () => {
            isStreaming            = true;
            statusDiv.innerText    = 'Status: Listening...';
            startStopBtn.innerText = 'Stop Session';
            startStopBtn.disabled  = false;

            keepAliveInterval = setInterval(() => {
                if (websocket && websocket.readyState === WebSocket.OPEN) {
                    websocket.send(JSON.stringify({ type: 'ping' }));
                }
            }, 10000);
        };

        workletNode.port.onmessage = (event) => {
            if (isStreaming && websocket.readyState === WebSocket.OPEN) {
                websocket.send(event.data);
            }
        };

        websocket.onmessage = handleServerMessage;
        websocket.onclose   = () => { stopSession(); };

    } catch (err) {
        console.error('Microphone/WS Error:', err);
        statusDiv.innerText    = 'Error: Check Mic Permissions.';
        startStopBtn.disabled  = false;
        startStopBtn.innerText = 'Start Session';
    }
}

// ─── MESSAGE HANDLER ─────────────────────────────────────────────────────────
//
// Nova Sonic sends events in this pattern per spoken turn:
//
//   [text events...]  ← one or more, may arrive before OR interleaved with audio
//   [binary pcm...]   ← raw Int16 audio frames
//   audio_end         ← signals end of this audio content block
//
// Strategy:
//   - Buffer ALL text events into pendingLipText (reset on each audio_end).
//   - Buffer ALL binary frames into turnPcmChunks.
//   - On audio_end: if we have PCM, flatten + enqueue for sequential playback.
//     If no PCM (text-only turn), keep pendingLipText so it carries forward
//     to pair with the next audio_end that does have PCM.
//   - The speak queue ensures each speakAudio call finishes before the next
//     starts, preventing avatar mouth collisions.

let turnPcmChunks  = [];   // raw PCM for the current audio block
let pendingLipText = '';   // accumulated text for the current/upcoming audio block

async function handleServerMessage(event) {
    if (typeof event.data === 'string') {
        const msg = JSON.parse(event.data);

        if (msg.type === 'text') {
            if (msg.role === 'ASSISTANT') {
                // Accumulate — audio arrives in same or next block
                pendingLipText += (pendingLipText ? ' ' : '') + msg.text;
                // Also log it (duplicate guard is inside logChat)
                logChat(pendingLipText.trim());
            }

        } else if (msg.type === 'interrupted') {
            // User barged in — clear everything immediately
            pendingLipText = '';
            turnPcmChunks  = [];
            speakQueue.length = 0;
            speakBusy      = false;
            audioQueue     = [];
            isPlayingAudio = false;
            if (avatar) avatar.stop();

        } else if (msg.type === 'audio_end') {
            const chunks = turnPcmChunks;
            turnPcmChunks = [];   // reset for next block

            if (chunks.length === 0) {
                // No audio in this block — keep pendingLipText for the next block
                return;
            }

            // Flatten PCM chunks into one Int16Array
            let totalLen = 0;
            for (const c of chunks) totalLen += c.length;
            const flattened = new Int16Array(totalLen);
            let offset = 0;
            for (const c of chunks) { flattened.set(c, offset); offset += c.length; }

            // Consume the accumulated text for this audio block
            const spokenText   = pendingLipText.trim();
            pendingLipText     = '';   // reset — next block gets a fresh slate

            console.log(`[audio_end] PCM ${totalLen} samples | text: "${spokenText.substring(0,60)}"`);

            if (avatar) {
                await enqueueSpeech(flattened, spokenText);
            } else {
                audioQueue.push(flattened);
                playNextInQueue();
            }

        } else if (msg.type === 'system') {
            logChat(`[System: ${msg.text}]`, 'System');
        }

    } else if (event.data instanceof ArrayBuffer) {
        turnPcmChunks.push(new Int16Array(event.data));
    }
}

// ─── STOP SESSION ────────────────────────────────────────────────────────────

function stopSession() {
    isStreaming     = false;
    pendingLipText  = '';
    turnPcmChunks   = [];
    speakQueue.length = 0;
    speakBusy       = false;
    audioQueue      = [];
    isPlayingAudio  = false;

    clearInterval(keepAliveInterval);
    keepAliveInterval = null;

    if (workletNode) workletNode.disconnect();
    if (micStream)   micStream.getTracks().forEach(t => t.stop());
    if (websocket)   websocket.close();
    if (audioCtx)    audioCtx.close();

    statusDiv.innerText    = 'Status: Disconnected';
    startStopBtn.disabled  = false;
    startStopBtn.innerText = 'Start Session';
}

// ─── CLEAR LOG ───────────────────────────────────────────────────────────────

function clearLog() {
    chatLog.innerHTML = '';
    lastLoggedText    = '';
}

// ─── INIT ────────────────────────────────────────────────────────────────────

startStopBtn.addEventListener('click', toggleSession);
clearLogBtn.addEventListener('click', clearLog);
startStopBtn.disabled = true;

window.onload = () => { initAvatar(); };
